# Migration Guide

*Migrating between major versions of JSQMessagesViewController?*

-----------------------------

## From `6.x` to `7.x`

See the [7.0 release notes](https://github.com/jessesquires/JSQMessagesViewController/releases/tag/7.0.0) for details about API changes.

## From `5.x` to `6.x`

See the [6.0 release notes](https://github.com/jessesquires/JSQMessagesViewController/releases/tag/6.0.0) for details about API changes.

## Previous versions

Unfortunately, versions prior to `5.0` outdate this document, and guides are not available.
