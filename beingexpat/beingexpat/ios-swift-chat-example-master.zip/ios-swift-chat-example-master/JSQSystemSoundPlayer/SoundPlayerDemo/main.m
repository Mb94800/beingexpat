//
//  main.m
//  SoundPlayerDemo
//
//  Created by Jesse Squires on 11/14/13.
//  Copyright (c) 2013 Hexed Bits. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JSQAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JSQAppDelegate class]));
    }
}
